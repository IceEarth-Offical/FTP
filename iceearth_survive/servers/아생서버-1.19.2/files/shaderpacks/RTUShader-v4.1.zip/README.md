# **RTU**Shader
BSL edited Shader by IPECTER 이팩터

**[다운로드](https://github.com/IPECTER/RTUShader/releases/tag/v3.1)**

With RTU 서버 리소스팩
![image](https://user-images.githubusercontent.com/80433772/208294565-966c836a-0129-4852-8d0e-c7a4568d50a2.png)
![image](https://user-images.githubusercontent.com/80433772/208294580-6adbe30c-9fa8-4127-8598-4c9a11146fdc.png)
![image](https://user-images.githubusercontent.com/80433772/208294574-839c7f50-c3bb-48e4-91e3-332fa7f7967f.png)

BSL : https://bitslablab.com/bslshaders/

## Referenced Shaders
- LexBoosT/AstraLex Shaders
- Septonious/Prismarine Shader
